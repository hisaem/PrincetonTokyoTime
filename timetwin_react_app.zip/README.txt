# TimeTwin — Princeton/Tokyo Time App (React)

This is a React app that shows paired times for Princeton and Tokyo, with AM/PM format and custom time control.

## How to use

1. Create a new React project (e.g., with Vite or CRA).
2. Replace the contents of `src/App.jsx` with the code from this version.
3. Run `npm run dev` to preview the app.
